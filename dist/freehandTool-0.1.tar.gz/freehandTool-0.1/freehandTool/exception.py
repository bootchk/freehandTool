'''
Created on Jul 3, 2013

@author: bootch
'''

class FreehandNullSegmentError(Exception):
    """
    Exception raised on attempt to generate a null segment.
    
    See comments in freehand.py
    """
    pass